<?php
include('./index.php');
?>